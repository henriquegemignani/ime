/*******************************************************************/
/** LINKED LIST interface definition                              **/
/** Requires: an ITEM implementation                              **/
/** Implementation: LLDOUBLE.c                                    **/
/**                                                               **/
/** Developed by:                                                 **/
/** Henrique Gemignani Passos Lima      nUSP: 6879634             **/
/*******************************************************************/

#ifndef LL_H_
#define LL_H_

typedef int item;

typedef struct LL *list;

/* Devolve o N-esimo termo, indo na direcao PROX, partindo de L. */
list LISTgetNterm( list l, int n );

/* Devolve o ultimo termo, indo na direcao PROX, partindo de L. */
list LISTgetLASTterm( list l );

/* Remove L, corrigindo os apontadores dos elementos proximos. */
void LISTremove( list l );

void LISTremoveNext( list l );

/* Finaliza uma lista ligada. */
void LISTdestroy( list l );

/* Inicializa uma lista ligada. */
list LISTinit();

/* Adiciona um novo elemento a lista, colocando-o no inicio da lista
 logo a frente de L. */
list LISTaddStart( list l, item it );

/* Adiciona um novo elemento a lista, colocando-o 
 no fim da lista na direcao PROX, partindo de L. */
list LISTaddEnd( list l, item it );

/* Devolve 1 se a lista ligada esta vazia, 0 caso contrario. */
int LISTempty( list l );

/* Devolve o item associado a L. */
item LISTgetVal( list l );

/* DEBUG!! Imprime o estado atual da lista.
 Nota: deixei essa funcao aqui pq eu gostei de como ela ficou. ;) */
void LISTdump( list l );

#endif

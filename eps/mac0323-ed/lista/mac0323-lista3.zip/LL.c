/*******************************************************************/
/** LINKED LIST implementation                                    **/
/** Requires: nothing extra                                       **/
/** Header: LL.h                                                  **/
/**                                                               **/
/** Developed by:                                                 **/
/** Henrique Gemignani Passos Lima      nUSP: 6879634             **/
/*******************************************************************/

#include "LL.h"
#include <stdio.h>
#include <stdlib.h>

struct LL {
    item it;
    list lt;
};

list LISTgetNterm( list l, int n ) {
    list p = l;
    int i;
    for( i = 0; p && i < n; i++ )
        p = p->lt;
    return p;
}

list LISTgetLASTterm( list l ) {
    list p;
    for( p = l; p != NULL && p->lt != NULL; p = p->lt );
    return p;
}

void LISTremove( list l ) {
    free(l);
}

void LISTremoveNext( list l ) {
    list p;
    if( l->lt ) {
        p = l->lt;
        l->lt = p->lt;
        free( p );
    }
}

/* Finaliza uma lista ligada. */
void LISTdestroy( list l ) {
    list p;
    for( p = l; p; l = p ) {
        p = l->lt;
        free( l );
    }
}

/* Inicializa uma lista ligada. */
list LISTinit() {
    return NULL;
}

/* Adiciona um novo elemento a lista, colocando-o no inicio da lista
 logo a frente de L. */
list LISTaddStart( list l, item it ) {
    list n = malloc( sizeof *n );
    n->it = it;
    n->lt = NULL;
    if( !l ) return n;
    n->lt = l->lt;
    l->lt = n;
    return l;
}

/* Adiciona um novo elemento a lista, colocando-o 
 no fim da lista na direcao PROX, partindo de L. */
list LISTaddEnd( list l, item it ) {
    list p, n = malloc( sizeof *n );
    n->it = it;
    n->lt = NULL;
    if( !l ) return n;
    for( p = l; p->lt; p = p->lt );
    p->lt = n;
    return l;
}

/* Devolve 1 se a lista ligada esta vazia, 0 caso contrario. */
int LISTempty( list l ) {
    return (l == NULL);
}

/* Devolve o item associado a L. */
item LISTgetVal( list l ) {
    return l->it;
}

void LISTdump( list l ) {
    list p = l;
    while( p != NULL ) {
        printf("%d%s", (int) p->it, p->lt ? " -> " : "\n" );
        p = p->lt;
    }
}

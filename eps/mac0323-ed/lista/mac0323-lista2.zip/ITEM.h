/*******************************************************************/
/** ITEM interface definition                                     **/
/** Requires: nothing                                             **/
/** Implementation: ITEM.c                                        **/
/**                                                               **/
/** Developed by:                                                 **/
/** Henrique Gemignani Passos Lima      nUSP: 6879634             **/
/*******************************************************************/

#ifndef ITEM_H_
#define ITEM_H_

typedef struct Item {
    int key, val;
} item;

item ITEMcreate( int key, int val );
int  ITEMval( item it );
int  ITEMkey( item it );
void ITEMprint( item it );

#endif

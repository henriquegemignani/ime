/*******************************************************************/
/** ITEM implementation                                           **/
/** Requires: nothing extra                                       **/
/** Header: ITEM.h                                                **/
/**                                                               **/
/** Developed by:                                                 **/
/** Henrique Gemignani Passos Lima      nUSP: 6879634             **/
/*******************************************************************/

#include "ITEM.h"
#include <stdio.h>

item ITEMcreate( int key, int val ) {
    item it;
    it.key = key;
    it.val = val;
    return it;
}

int  ITEMval( item it ) { 
    return it.val;
}

int  ITEMkey( item it ) {
    return it.key;
}

void ITEMprint( item it ) {
    printf("(%d,%d) ", it.key, it.val );
}

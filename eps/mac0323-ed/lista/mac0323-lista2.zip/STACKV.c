/*******************************************************************/
/** STACK vector implementation                                   **/
/** Requires: nothing extra                                       **/
/** Header: STACK.h                                               **/
/**                                                               **/
/** Developed by:                                                 **/
/** Henrique Gemignani Passos Lima      nUSP: 6879634             **/
/*******************************************************************/

#include "ITEM.h"
#include "STACK.h"

#include <stdio.h>
#include <stdlib.h>

#define STvect(s) (*s)->itv
#define STsize(s) (*s)->maxsize
#define STcur(s)  (*s)->cur

struct Stack {
    item * itv;
    int maxsize, cur;
};

void STACKdump(stack s) {
    int i;
    for( i = STcur(s); i > 0; i-- ) {
        ITEMprint( STvect(s)[ i - 1 ] );
        if( i > 1 ) printf("-> ");
    }
    printf("\n");
}
stack STACKinit(int maxN) {
    stack s = malloc( sizeof(*s) );
    if( !s ) return NULL;
    *s = malloc( sizeof(*(*s)) );
    if( !(*s) ) {
        free(s);
        return NULL;
    }
    STvect(s) = malloc( maxN * sizeof(*STvect(s)) );
    if( !STvect(s) ) {
        free(*s);
        free(s);
        return NULL;
    }
    STsize(s) = maxN;
    STcur(s) = 0;
    return s;
}
int STACKempty(stack s) {
    return STcur(s) == 0;
}
int STACKpush(stack s, item it) {
    if( STcur(s) == STsize(s) )
        return 0;
    STvect(s)[STcur(s)++] = it;
    return 1;
}
item STACKpeek(stack s) {
    return STvect(s)[STcur(s)-1];
}
item STACKpop(stack s) {
    return STvect(s)[--STcur(s)];
}

int STACKsize(stack s) {
    return STcur(s);
}

/*******************************************************************/
/** STACK interface definition                                    **/
/** Requires: an ITEM implementation                              **/
/** Implementation: STACKLL.c                                     **/
/**                                                               **/
/** Developed by:                                                 **/
/** Henrique Gemignani Passos Lima      nUSP: 6879634             **/
/*******************************************************************/

#ifndef STACK_H_
#define STACK_H_

#include "ITEM.h"

typedef struct Stack **stack;
 void STACKdump(stack s);
stack STACKinit(int maxN);
  int STACKempty(stack);
  int STACKpush(stack s, item it);
 item STACKpeek(stack s);
 item STACKpop(stack s);
  int STACKsize(stack s);

#endif
